#Authored by: Nikhil Khatu for the CSC570 project

VBoxManage unregistervm "vh03_new Clone"

