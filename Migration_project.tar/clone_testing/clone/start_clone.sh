#Authored by: Nikhil Khatu for the CSC570 project

#VBoxManage startvm "vh01_new Clone_test"
#VBoxManage startvm "vh02_new Clone_test"
#VBoxManage startvm "vh03_new Clone_test"

