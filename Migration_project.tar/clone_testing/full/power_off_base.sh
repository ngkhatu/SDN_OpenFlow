#Authored by: Nikhil Khatu for the CSC570 project

VBoxManage controlvm "vh01_old Clone_test" poweroff
VBoxManage controlvm "vh02_old Clone_test" poweroff
VBoxManage controlvm "vh03_old Clone_test" poweroff
VBoxManage controlvm "ofcontroller Clone" poweroff
VBoxManage controlvm "router Clone" poweroff

