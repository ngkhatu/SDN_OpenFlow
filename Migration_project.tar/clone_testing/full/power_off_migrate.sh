#Authored by: Nikhil Khatu for the CSC570 project

VBoxManage controlvm "vh01_new Clone_test" poweroff
VBoxManage controlvm "vh02_new Clone_test" poweroff
VBoxManage controlvm "vh03_new Clone_test" poweroff
VBoxManage controlvm "ofcontroller Clone" poweroff
VBoxManage controlvm "router Clone" poweroff
