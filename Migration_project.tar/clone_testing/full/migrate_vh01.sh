#Authored by: Nikhil Khatu for the CSC570 project

VBoxManage startvm "vh01_new Clone_test" &
sleep 1
VBoxManage controlvm "vh01_old Clone_test" teleport --host "localhost" --port "6000" --password csc570
